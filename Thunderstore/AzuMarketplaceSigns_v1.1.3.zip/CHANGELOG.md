| `Version` | `Update Notes`                                                                                               |
|-----------|--------------------------------------------------------------------------------------------------------------|
| 1.1.3     | - Update for Valheim's latest version.                                                                       |
| 1.1.2     | - Update ServerSync again.                                                                                   |
| 1.1.1     | - Update ServerSync                                                                                          |
| 1.1.0     | -  Added live update of sign text when the config is changed.<br/> - Update ServerSync and PieceManager code |
| 1.0.0     | - Initial Release                                                                                            |